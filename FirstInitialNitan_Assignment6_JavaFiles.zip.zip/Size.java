/*
 * Class: CMSC203 
 * Instructor:Ashique Tanveer
 * Description: (Bradley Beverage Shop)
 * Due: 04/30/2024
 * Platform/compiler:
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Touch Nitan
*/
public enum Size {
	SMALL,
	MEDIUM, 
	LARGE

}